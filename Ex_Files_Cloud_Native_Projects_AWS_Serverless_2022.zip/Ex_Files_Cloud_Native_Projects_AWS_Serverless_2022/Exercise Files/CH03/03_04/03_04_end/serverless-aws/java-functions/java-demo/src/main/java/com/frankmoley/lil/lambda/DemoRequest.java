package com.frankmoley.lil.lambda;

import java.io.Serializable;

public class DemoRequest implements Serializable {
    private int count;
    private String message;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
