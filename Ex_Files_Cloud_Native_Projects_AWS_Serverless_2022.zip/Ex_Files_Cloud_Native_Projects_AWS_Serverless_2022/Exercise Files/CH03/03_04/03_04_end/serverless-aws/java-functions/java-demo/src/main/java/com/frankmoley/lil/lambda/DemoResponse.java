package com.frankmoley.lil.lambda;

import java.io.Serializable;

public class DemoResponse implements Serializable {
    private int executions;

    public int getExecutions() {
        return executions;
    }

    public void setExecutions(int executions) {
        this.executions = executions;
    }
}
