package com.frankmoley.lil.lambda;

public class CoinTossResponse {
    private int flips;
    private int heads;
    private int tails;

    public int getFlips() {
        return flips;
    }

    public void setFlips(int flips) {
        this.flips = flips;
    }

    public int getHeads() {
        return heads;
    }

    public void setHeads(int heads) {
        this.heads = heads;
    }

    public int getTails() {
        return tails;
    }

    public void setTails(int tails) {
        this.tails = tails;
    }

    public void incrementHeads(){
        this.heads++;
    }

    public void incrementTails(){
        this.tails++;
    }
}
