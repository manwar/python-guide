package com.frankmoley.lil.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class DemoHandler implements RequestHandler<DemoRequest, DemoResponse> {
    @Override
    public DemoResponse handleRequest(DemoRequest event, Context context) {
        LambdaLogger logger = context.getLogger();
        for (int i=0;i<event.getCount();i++){
            logger.log(event.getMessage() + "\n");
        }
        DemoResponse response = new DemoResponse();
        response.setExecutions(event.getCount());
        return response;
    }
}
