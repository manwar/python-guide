package com.frankmoley.lil.lambda;

import java.util.Random;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class CoinTossHandler implements RequestHandler<CoinTossRequest, CoinTossResponse> {

    @Override
    public CoinTossResponse handleRequest(CoinTossRequest event, Context context) {
        LambdaLogger logger = context.getLogger();
        CoinTossResponse response = new CoinTossResponse();
        response.setFlips(event.getCount());
        Random random= new Random();
        for(int i=0;i<event.getCount();i++){
            if(random.nextBoolean()){
                logger.log("Flip " + i + "found heads");
                response.incrementHeads();
            }else{
                logger.log("Flip " + i + "found tails");
                response.incrementTails();
            }
        }
        return response;
    }
}
