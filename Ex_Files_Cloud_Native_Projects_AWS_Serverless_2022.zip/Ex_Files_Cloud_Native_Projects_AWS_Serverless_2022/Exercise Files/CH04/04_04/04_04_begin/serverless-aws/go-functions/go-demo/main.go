package main

import (
	"context"
	"github.com/aws/aws-lambda-go/lambda"
	"log"
)

type Request struct{
	Count int `json:"count"`
	Message string `json:"message"`
}

type Response struct{
	Status string `json:"status"`
}

func HandleRequest(ctx context.Context, request Request)(Response, error){
	log.Printf("Hello from go, its time to get some work done %d times", request.Count)
	for i:=0;i<request.Count;i++{
		log.Print(request.Message)
	}
	return Response{"200 OK, all done"}, nil
}

func main() {
	lambda.Start(HandleRequest)
}
