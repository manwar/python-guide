package main

import (
	"context"
	"fmt"
	"github.com/aws/aws-lambda-go/lambda"
	"log"
)
const(
	fizz = "fizz"
	buzz = "buzz"
)

type Request struct{
	Count int `json:"count"`
}

type Response struct{
	Count int `json:"count"`
	FizzCount int `json:"fizz_count"`
	BuzzCount int `json:"buzz_count"`
	FizzBuzzCount int `json:"fizz_buzz_count"`
}

func Handler(ctx context.Context, request Request)(Response, error){
	log.Print("starting execution")
	fizzCount:=0
	buzzCount:=0
	fizzBuzzCount:=0
	for i := 1;i <= request.Count; i++ {
		if i % 3 == 0 && i % 5 == 0 {
			fmt.Println(fizz + buzz)
			fizzBuzzCount++
		} else if i % 3 == 0 {
			fmt.Println(fizz)
			fizzCount++
		} else if i % 5 == 0 {
			fmt.Println(buzz)
			buzzCount++
		} else{
			fmt.Println(i)
		}
	}
	return Response{
		Count:         request.Count,
		FizzCount:     fizzCount,
		BuzzCount:     buzzCount,
		FizzBuzzCount: fizzBuzzCount,
	},nil
}

func main(){
	lambda.Start(Handler)
}
